var mraa = require("mraa");
var mqtt = require('mqtt');
var myAnalogPin = new mraa.Aio(0);
var B = 3975;
var port = 1883;
var broker = "quickstart.messaging.internetofthings.ibmcloud.com";
var topic = "iot-2/evt/status/fmt/json";
var organization = "quickstart";
var deviceType = "temp-galileo";
require('getmac').getMac(function (err, macAddress) {
    if (err) throw err;
    macAddress = macAddress.toString().replace(/:/g, '').toLowerCase();
    console.log("Temperature Sensor publishing from " + macAddress);
    var options = {};
    options.clientId = "d:" + organization + ":" + deviceType + ":" + macAddress;
    var client = mqtt.createClient(port, broker, options);
    topic = "iot-2/evt/status/fmt/json";
    var message = {};
    message.d = {};
    setInterval(function () {
        var a = myAnalogPin.read();
        var resistance = (1023 - a) * 10000 / a;
        var celsius_temperature = 1 / (Math.log(resistance / 10000) / B + 1 / 298.15) - 273.15;
        message.d.temp = celsius_temperature;
        client.publish(topic, JSON.stringify(message));
        console.log("Celsius Temperature " + celsius_temperature);
    }, 4000);
});